﻿namespace Secretariat_Soft.CommForms
{
    partial class Users_de
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.Top_Toolstrip = new System.Windows.Forms.ToolStrip();
            this.add_butt = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.edit_butt = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.del_butt = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.save_butt = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.cancel_butt = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sys_time_lbl = new System.Windows.Forms.Label();
            this.appusers_bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.letters1 = new Secretariat_Soft.Ds.Letters();
            this.label8 = new System.Windows.Forms.Label();
            this.sys_date_lbl = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.user_id_lbl = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.user_name_lbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.main_gbox = new System.Windows.Forms.GroupBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.checkBox27 = new System.Windows.Forms.CheckBox();
            this.checkBox29 = new System.Windows.Forms.CheckBox();
            this.checkBox30 = new System.Windows.Forms.CheckBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.checkBox28 = new System.Windows.Forms.CheckBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.checkBox17 = new System.Windows.Forms.CheckBox();
            this.checkBox18 = new System.Windows.Forms.CheckBox();
            this.checkBox19 = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.checkBox23 = new System.Windows.Forms.CheckBox();
            this.checkBox24 = new System.Windows.Forms.CheckBox();
            this.checkBox25 = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.checkBox20 = new System.Windows.Forms.CheckBox();
            this.checkBox21 = new System.Windows.Forms.CheckBox();
            this.checkBox22 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.browse_button1 = new System.Windows.Forms.Button();
            this.user_pictureBox1 = new System.Windows.Forms.PictureBox();
            this.comment_textBox1 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.pass_repeat_textBox1 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.pass_textBox2 = new System.Windows.Forms.TextBox();
            this.un_textBox1 = new System.Windows.Forms.TextBox();
            this.id_label21 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.appUsersTableAdapter1 = new Secretariat_Soft.Ds.LettersTableAdapters.AppUsersTableAdapter();
            this.id_label5 = new System.Windows.Forms.Label();
            this.Top_Toolstrip.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appusers_bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.letters1)).BeginInit();
            this.main_gbox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.user_pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Top_Toolstrip
            // 
            this.Top_Toolstrip.AutoSize = false;
            this.Top_Toolstrip.BackgroundImage = global::Secretariat_Soft.Properties.Resources.butt_background;
            this.Top_Toolstrip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Top_Toolstrip.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.Top_Toolstrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.Top_Toolstrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.add_butt,
            this.toolStripSeparator1,
            this.edit_butt,
            this.toolStripSeparator5,
            this.del_butt,
            this.toolStripSeparator4,
            this.save_butt,
            this.toolStripSeparator3,
            this.cancel_butt,
            this.toolStripSeparator6});
            this.Top_Toolstrip.Location = new System.Drawing.Point(0, 0);
            this.Top_Toolstrip.Name = "Top_Toolstrip";
            this.Top_Toolstrip.Size = new System.Drawing.Size(785, 56);
            this.Top_Toolstrip.TabIndex = 2;
            this.Top_Toolstrip.Text = "toolStrip1";
            // 
            // add_butt
            // 
            this.add_butt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.add_butt.Image = global::Secretariat_Soft.Properties.Resources.de_new_butt;
            this.add_butt.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.add_butt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.add_butt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.add_butt.Name = "add_butt";
            this.add_butt.Size = new System.Drawing.Size(94, 53);
            this.add_butt.Text = "Add New F2";
            this.add_butt.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.add_butt.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            this.add_butt.Click += new System.EventHandler(this.add_butt_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 56);
            // 
            // edit_butt
            // 
            this.edit_butt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.edit_butt.Image = global::Secretariat_Soft.Properties.Resources.de_edit_butt_;
            this.edit_butt.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.edit_butt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.edit_butt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.edit_butt.Name = "edit_butt";
            this.edit_butt.Size = new System.Drawing.Size(58, 53);
            this.edit_butt.Text = "Edit F3";
            this.edit_butt.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.edit_butt.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            this.edit_butt.Click += new System.EventHandler(this.edit_butt_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 56);
            // 
            // del_butt
            // 
            this.del_butt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.del_butt.Image = global::Secretariat_Soft.Properties.Resources.de_delete_butt;
            this.del_butt.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.del_butt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.del_butt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.del_butt.Name = "del_butt";
            this.del_butt.Size = new System.Drawing.Size(76, 53);
            this.del_butt.Text = "Delete F4";
            this.del_butt.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.del_butt.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            this.del_butt.Click += new System.EventHandler(this.del_butt_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 56);
            // 
            // save_butt
            // 
            this.save_butt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.save_butt.Image = global::Secretariat_Soft.Properties.Resources.de_save_butt;
            this.save_butt.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.save_butt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.save_butt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.save_butt.Name = "save_butt";
            this.save_butt.Size = new System.Drawing.Size(63, 53);
            this.save_butt.Text = "Save F5";
            this.save_butt.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.save_butt.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            this.save_butt.Click += new System.EventHandler(this.save_butt_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 56);
            // 
            // cancel_butt
            // 
            this.cancel_butt.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cancel_butt.Image = global::Secretariat_Soft.Properties.Resources.de_button_cancel24;
            this.cancel_butt.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.cancel_butt.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.cancel_butt.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.cancel_butt.Name = "cancel_butt";
            this.cancel_butt.Size = new System.Drawing.Size(76, 53);
            this.cancel_butt.Text = "Cancel F6";
            this.cancel_butt.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.cancel_butt.TextImageRelation = System.Windows.Forms.TextImageRelation.Overlay;
            this.cancel_butt.Click += new System.EventHandler(this.cancel_butt_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 56);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.sys_time_lbl);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.sys_date_lbl);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.user_id_lbl);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.user_name_lbl);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 680);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(785, 32);
            this.panel1.TabIndex = 3;
            // 
            // sys_time_lbl
            // 
            this.sys_time_lbl.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appusers_bindingSource1, "SysTime", true));
            this.sys_time_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.sys_time_lbl.Location = new System.Drawing.Point(655, 5);
            this.sys_time_lbl.Name = "sys_time_lbl";
            this.sys_time_lbl.Size = new System.Drawing.Size(95, 20);
            this.sys_time_lbl.TabIndex = 7;
            this.sys_time_lbl.Text = "-";
            this.sys_time_lbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // appusers_bindingSource1
            // 
            this.appusers_bindingSource1.DataMember = "AppUsers";
            this.appusers_bindingSource1.DataSource = this.letters1;
            // 
            // letters1
            // 
            this.letters1.DataSetName = "Letters";
            this.letters1.Namespace = "http://tempuri.org/Letters.xsd";
            this.letters1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(553, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 20);
            this.label8.TabIndex = 6;
            this.label8.Text = "System Time:";
            // 
            // sys_date_lbl
            // 
            this.sys_date_lbl.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appusers_bindingSource1, "SysDate", true));
            this.sys_date_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.sys_date_lbl.Location = new System.Drawing.Point(451, 5);
            this.sys_date_lbl.Name = "sys_date_lbl";
            this.sys_date_lbl.Size = new System.Drawing.Size(105, 20);
            this.sys_date_lbl.TabIndex = 5;
            this.sys_date_lbl.Text = "-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(350, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 20);
            this.label6.TabIndex = 4;
            this.label6.Text = "System Date:";
            // 
            // user_id_lbl
            // 
            this.user_id_lbl.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appusers_bindingSource1, "Sys_UserId", true));
            this.user_id_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.user_id_lbl.Location = new System.Drawing.Point(299, 5);
            this.user_id_lbl.Name = "user_id_lbl";
            this.user_id_lbl.Size = new System.Drawing.Size(59, 20);
            this.user_id_lbl.TabIndex = 3;
            this.user_id_lbl.Text = "-";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(238, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 20);
            this.label4.TabIndex = 2;
            this.label4.Text = "User id:";
            // 
            // user_name_lbl
            // 
            this.user_name_lbl.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appusers_bindingSource1, "Sys_User", true));
            this.user_name_lbl.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.user_name_lbl.Location = new System.Drawing.Point(92, 5);
            this.user_name_lbl.Name = "user_name_lbl";
            this.user_name_lbl.Size = new System.Drawing.Size(149, 20);
            this.user_name_lbl.TabIndex = 1;
            this.user_name_lbl.Text = "-";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "User Name:";
            // 
            // main_gbox
            // 
            this.main_gbox.Controls.Add(this.groupBox1);
            this.main_gbox.Controls.Add(this.browse_button1);
            this.main_gbox.Controls.Add(this.user_pictureBox1);
            this.main_gbox.Controls.Add(this.comment_textBox1);
            this.main_gbox.Controls.Add(this.label7);
            this.main_gbox.Controls.Add(this.pass_repeat_textBox1);
            this.main_gbox.Controls.Add(this.label3);
            this.main_gbox.Controls.Add(this.pass_textBox2);
            this.main_gbox.Controls.Add(this.un_textBox1);
            this.main_gbox.Controls.Add(this.id_label21);
            this.main_gbox.Controls.Add(this.label9);
            this.main_gbox.Controls.Add(this.label5);
            this.main_gbox.Controls.Add(this.label2);
            this.main_gbox.Location = new System.Drawing.Point(7, 79);
            this.main_gbox.Name = "main_gbox";
            this.main_gbox.Size = new System.Drawing.Size(772, 595);
            this.main_gbox.TabIndex = 4;
            this.main_gbox.TabStop = false;
            this.main_gbox.Text = "Info";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.groupBox8);
            this.groupBox1.Controls.Add(this.groupBox7);
            this.groupBox1.Controls.Add(this.groupBox5);
            this.groupBox1.Controls.Add(this.groupBox6);
            this.groupBox1.Controls.Add(this.groupBox4);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Controls.Add(this.groupBox2);
            this.groupBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(6, 226);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(760, 358);
            this.groupBox1.TabIndex = 88;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Permissions";
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.checkBox27);
            this.groupBox8.Controls.Add(this.checkBox29);
            this.groupBox8.Controls.Add(this.checkBox30);
            this.groupBox8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox8.Location = new System.Drawing.Point(590, 191);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(170, 143);
            this.groupBox8.TabIndex = 6;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "User List Data Entry";
            // 
            // checkBox27
            // 
            this.checkBox27.AutoSize = true;
            this.checkBox27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox27.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "User_de_b3", true));
            this.checkBox27.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox27.Location = new System.Drawing.Point(15, 78);
            this.checkBox27.Name = "checkBox27";
            this.checkBox27.Size = new System.Drawing.Size(75, 24);
            this.checkBox27.TabIndex = 2;
            this.checkBox27.Text = "Delete";
            this.checkBox27.UseVisualStyleBackColor = true;
            // 
            // checkBox29
            // 
            this.checkBox29.AutoSize = true;
            this.checkBox29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox29.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "User_de_b2", true));
            this.checkBox29.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox29.Location = new System.Drawing.Point(15, 49);
            this.checkBox29.Name = "checkBox29";
            this.checkBox29.Size = new System.Drawing.Size(57, 24);
            this.checkBox29.TabIndex = 1;
            this.checkBox29.Text = "Edit";
            this.checkBox29.UseVisualStyleBackColor = true;
            // 
            // checkBox30
            // 
            this.checkBox30.AutoSize = true;
            this.checkBox30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox30.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "User_de_b1", true));
            this.checkBox30.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox30.Location = new System.Drawing.Point(15, 21);
            this.checkBox30.Name = "checkBox30";
            this.checkBox30.Size = new System.Drawing.Size(61, 24);
            this.checkBox30.TabIndex = 0;
            this.checkBox30.Text = "New";
            this.checkBox30.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.checkBox28);
            this.groupBox7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox7.Location = new System.Drawing.Point(586, 41);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(168, 134);
            this.groupBox7.TabIndex = 5;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "User List";
            // 
            // checkBox28
            // 
            this.checkBox28.AutoSize = true;
            this.checkBox28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox28.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "User_List_b1", true));
            this.checkBox28.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox28.Location = new System.Drawing.Point(9, 26);
            this.checkBox28.Name = "checkBox28";
            this.checkBox28.Size = new System.Drawing.Size(136, 24);
            this.checkBox28.TabIndex = 0;
            this.checkBox28.Text = "Add | Edit Users";
            this.checkBox28.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.checkBox16);
            this.groupBox5.Controls.Add(this.checkBox17);
            this.groupBox5.Controls.Add(this.checkBox18);
            this.groupBox5.Controls.Add(this.checkBox19);
            this.groupBox5.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox5.Location = new System.Drawing.Point(406, 185);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(170, 143);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Out Letters Data Entry";
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox16.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "Out_de_b4", true));
            this.checkBox16.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox16.Location = new System.Drawing.Point(15, 103);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(61, 24);
            this.checkBox16.TabIndex = 3;
            this.checkBox16.Text = "Print";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // checkBox17
            // 
            this.checkBox17.AutoSize = true;
            this.checkBox17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox17.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "Out_de_b3", true));
            this.checkBox17.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox17.Location = new System.Drawing.Point(15, 77);
            this.checkBox17.Name = "checkBox17";
            this.checkBox17.Size = new System.Drawing.Size(75, 24);
            this.checkBox17.TabIndex = 2;
            this.checkBox17.Text = "Delete";
            this.checkBox17.UseVisualStyleBackColor = true;
            // 
            // checkBox18
            // 
            this.checkBox18.AutoSize = true;
            this.checkBox18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox18.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "Out_de_b2", true));
            this.checkBox18.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox18.Location = new System.Drawing.Point(15, 51);
            this.checkBox18.Name = "checkBox18";
            this.checkBox18.Size = new System.Drawing.Size(57, 24);
            this.checkBox18.TabIndex = 1;
            this.checkBox18.Text = "Edit";
            this.checkBox18.UseVisualStyleBackColor = true;
            // 
            // checkBox19
            // 
            this.checkBox19.AutoSize = true;
            this.checkBox19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox19.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "Out_de_b1", true));
            this.checkBox19.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox19.Location = new System.Drawing.Point(15, 21);
            this.checkBox19.Name = "checkBox19";
            this.checkBox19.Size = new System.Drawing.Size(61, 24);
            this.checkBox19.TabIndex = 0;
            this.checkBox19.Text = "New";
            this.checkBox19.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.checkBox23);
            this.groupBox6.Controls.Add(this.checkBox24);
            this.groupBox6.Controls.Add(this.checkBox25);
            this.groupBox6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox6.Location = new System.Drawing.Point(406, 39);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(170, 134);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Out Letters List";
            // 
            // checkBox23
            // 
            this.checkBox23.AutoSize = true;
            this.checkBox23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox23.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "Out_List_b3", true));
            this.checkBox23.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox23.Location = new System.Drawing.Point(15, 86);
            this.checkBox23.Name = "checkBox23";
            this.checkBox23.Size = new System.Drawing.Size(61, 24);
            this.checkBox23.TabIndex = 2;
            this.checkBox23.Text = "Print";
            this.checkBox23.UseVisualStyleBackColor = true;
            // 
            // checkBox24
            // 
            this.checkBox24.AutoSize = true;
            this.checkBox24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox24.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "Out_List_b2", true));
            this.checkBox24.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox24.Location = new System.Drawing.Point(15, 56);
            this.checkBox24.Name = "checkBox24";
            this.checkBox24.Size = new System.Drawing.Size(75, 24);
            this.checkBox24.TabIndex = 1;
            this.checkBox24.Text = "Search";
            this.checkBox24.UseVisualStyleBackColor = true;
            // 
            // checkBox25
            // 
            this.checkBox25.AutoSize = true;
            this.checkBox25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox25.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "Out_List_b1", true));
            this.checkBox25.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox25.Location = new System.Drawing.Point(15, 26);
            this.checkBox25.Name = "checkBox25";
            this.checkBox25.Size = new System.Drawing.Size(128, 24);
            this.checkBox25.TabIndex = 0;
            this.checkBox25.Text = "Add | Edit Doc";
            this.checkBox25.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.checkBox15);
            this.groupBox4.Controls.Add(this.checkBox12);
            this.groupBox4.Controls.Add(this.checkBox13);
            this.groupBox4.Controls.Add(this.checkBox14);
            this.groupBox4.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox4.Location = new System.Drawing.Point(239, 185);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(156, 143);
            this.groupBox4.TabIndex = 2;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "In Letters Data Entry";
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox15.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "In_de_b4", true));
            this.checkBox15.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox15.Location = new System.Drawing.Point(15, 103);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(61, 24);
            this.checkBox15.TabIndex = 3;
            this.checkBox15.Text = "Print";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox12.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "In_de_b3", true));
            this.checkBox12.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox12.Location = new System.Drawing.Point(15, 77);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(75, 24);
            this.checkBox12.TabIndex = 2;
            this.checkBox12.Text = "Delete";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox13.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "In_de_b2", true));
            this.checkBox13.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox13.Location = new System.Drawing.Point(15, 51);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(57, 24);
            this.checkBox13.TabIndex = 1;
            this.checkBox13.Text = "Edit";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox14.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "In_de_b1", true));
            this.checkBox14.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox14.Location = new System.Drawing.Point(15, 26);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(61, 24);
            this.checkBox14.TabIndex = 0;
            this.checkBox14.Text = "New";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.checkBox20);
            this.groupBox3.Controls.Add(this.checkBox21);
            this.groupBox3.Controls.Add(this.checkBox22);
            this.groupBox3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox3.Location = new System.Drawing.Point(239, 31);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(156, 142);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "In Letters List";
            // 
            // checkBox20
            // 
            this.checkBox20.AutoSize = true;
            this.checkBox20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox20.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "In_List_b3", true));
            this.checkBox20.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox20.Location = new System.Drawing.Point(15, 86);
            this.checkBox20.Name = "checkBox20";
            this.checkBox20.Size = new System.Drawing.Size(61, 24);
            this.checkBox20.TabIndex = 2;
            this.checkBox20.Text = "Print";
            this.checkBox20.UseVisualStyleBackColor = true;
            // 
            // checkBox21
            // 
            this.checkBox21.AutoSize = true;
            this.checkBox21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox21.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "In_List_b2", true));
            this.checkBox21.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox21.Location = new System.Drawing.Point(15, 56);
            this.checkBox21.Name = "checkBox21";
            this.checkBox21.Size = new System.Drawing.Size(75, 24);
            this.checkBox21.TabIndex = 1;
            this.checkBox21.Text = "Search";
            this.checkBox21.UseVisualStyleBackColor = true;
            // 
            // checkBox22
            // 
            this.checkBox22.AutoSize = true;
            this.checkBox22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox22.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "In_List_b1", true));
            this.checkBox22.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox22.Location = new System.Drawing.Point(15, 26);
            this.checkBox22.Name = "checkBox22";
            this.checkBox22.Size = new System.Drawing.Size(128, 24);
            this.checkBox22.TabIndex = 0;
            this.checkBox22.Text = "Add | Edit Doc";
            this.checkBox22.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.checkBox11);
            this.groupBox2.Controls.Add(this.checkBox10);
            this.groupBox2.Controls.Add(this.checkBox9);
            this.groupBox2.Controls.Add(this.checkBox8);
            this.groupBox2.Controls.Add(this.checkBox7);
            this.groupBox2.Controls.Add(this.checkBox6);
            this.groupBox2.Controls.Add(this.checkBox5);
            this.groupBox2.Controls.Add(this.checkBox4);
            this.groupBox2.Controls.Add(this.checkBox3);
            this.groupBox2.Controls.Add(this.checkBox2);
            this.groupBox2.Controls.Add(this.checkBox1);
            this.groupBox2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(7, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(224, 332);
            this.groupBox2.TabIndex = 0;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Main Form";
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox11.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b4_m2", true));
            this.checkBox11.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox11.ForeColor = System.Drawing.Color.Maroon;
            this.checkBox11.Location = new System.Drawing.Point(47, 302);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(72, 24);
            this.checkBox11.TabIndex = 10;
            this.checkBox11.Text = "About";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox10.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b4_m1", true));
            this.checkBox10.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox10.ForeColor = System.Drawing.Color.Maroon;
            this.checkBox10.Location = new System.Drawing.Point(47, 274);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(63, 24);
            this.checkBox10.TabIndex = 9;
            this.checkBox10.Text = "Help";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox9.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b3_m3", true));
            this.checkBox9.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox9.ForeColor = System.Drawing.Color.Maroon;
            this.checkBox9.Location = new System.Drawing.Point(47, 216);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(117, 24);
            this.checkBox9.TabIndex = 8;
            this.checkBox9.Text = "Restore Data";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox8.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b3_m2", true));
            this.checkBox8.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox8.ForeColor = System.Drawing.Color.Maroon;
            this.checkBox8.Location = new System.Drawing.Point(47, 190);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(115, 24);
            this.checkBox8.TabIndex = 7;
            this.checkBox8.Text = "Backup Data";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox7.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b3_m1", true));
            this.checkBox7.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox7.ForeColor = System.Drawing.Color.Maroon;
            this.checkBox7.Location = new System.Drawing.Point(47, 163);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(66, 24);
            this.checkBox7.TabIndex = 6;
            this.checkBox7.Text = "Users";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox6.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b2_m2", true));
            this.checkBox6.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox6.ForeColor = System.Drawing.Color.Maroon;
            this.checkBox6.Location = new System.Drawing.Point(47, 108);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(142, 24);
            this.checkBox6.TabIndex = 5;
            this.checkBox6.Text = "Outgoing Letters";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox5.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b2_m1", true));
            this.checkBox5.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox5.ForeColor = System.Drawing.Color.Maroon;
            this.checkBox5.Location = new System.Drawing.Point(47, 83);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(141, 24);
            this.checkBox5.TabIndex = 4;
            this.checkBox5.Text = "Incoming Letters";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox4.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b4", true));
            this.checkBox4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox4.Location = new System.Drawing.Point(15, 244);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(63, 24);
            this.checkBox4.TabIndex = 3;
            this.checkBox4.Text = "Help";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox3.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b3", true));
            this.checkBox3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox3.Location = new System.Drawing.Point(16, 138);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(66, 24);
            this.checkBox3.TabIndex = 2;
            this.checkBox3.Text = "Tools";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox2.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b2", true));
            this.checkBox2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox2.Location = new System.Drawing.Point(15, 56);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(82, 24);
            this.checkBox2.TabIndex = 1;
            this.checkBox2.Text = "Reports";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.checkBox1.DataBindings.Add(new System.Windows.Forms.Binding("Checked", this.appusers_bindingSource1, "main_b1", true));
            this.checkBox1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.checkBox1.Location = new System.Drawing.Point(15, 26);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(100, 24);
            this.checkBox1.TabIndex = 0;
            this.checkBox1.Text = "Data Entry";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // browse_button1
            // 
            this.browse_button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.browse_button1.Location = new System.Drawing.Point(513, 143);
            this.browse_button1.Name = "browse_button1";
            this.browse_button1.Size = new System.Drawing.Size(114, 29);
            this.browse_button1.TabIndex = 87;
            this.browse_button1.Text = "Browse";
            this.browse_button1.UseVisualStyleBackColor = true;
            this.browse_button1.Click += new System.EventHandler(this.browse_button1_Click);
            // 
            // user_pictureBox1
            // 
            this.user_pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.user_pictureBox1.DataBindings.Add(new System.Windows.Forms.Binding("Image", this.appusers_bindingSource1, "Photo", true));
            this.user_pictureBox1.Location = new System.Drawing.Point(514, 18);
            this.user_pictureBox1.Name = "user_pictureBox1";
            this.user_pictureBox1.Size = new System.Drawing.Size(113, 122);
            this.user_pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.user_pictureBox1.TabIndex = 86;
            this.user_pictureBox1.TabStop = false;
            // 
            // comment_textBox1
            // 
            this.comment_textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appusers_bindingSource1, "Comment", true));
            this.comment_textBox1.Location = new System.Drawing.Point(216, 184);
            this.comment_textBox1.Name = "comment_textBox1";
            this.comment_textBox1.Size = new System.Drawing.Size(477, 27);
            this.comment_textBox1.TabIndex = 85;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(84, 186);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 20);
            this.label7.TabIndex = 84;
            this.label7.Text = "Comment:";
            // 
            // pass_repeat_textBox1
            // 
            this.pass_repeat_textBox1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pass_repeat_textBox1.Location = new System.Drawing.Point(216, 146);
            this.pass_repeat_textBox1.MaxLength = 10;
            this.pass_repeat_textBox1.Name = "pass_repeat_textBox1";
            this.pass_repeat_textBox1.PasswordChar = '*';
            this.pass_repeat_textBox1.Size = new System.Drawing.Size(164, 30);
            this.pass_repeat_textBox1.TabIndex = 83;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(84, 148);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 20);
            this.label3.TabIndex = 82;
            this.label3.Text = "Password Repeat:";
            // 
            // pass_textBox2
            // 
            this.pass_textBox2.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appusers_bindingSource1, "Password", true));
            this.pass_textBox2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.pass_textBox2.Location = new System.Drawing.Point(216, 108);
            this.pass_textBox2.MaxLength = 10;
            this.pass_textBox2.Name = "pass_textBox2";
            this.pass_textBox2.PasswordChar = '*';
            this.pass_textBox2.Size = new System.Drawing.Size(164, 30);
            this.pass_textBox2.TabIndex = 81;
            // 
            // un_textBox1
            // 
            this.un_textBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appusers_bindingSource1, "User_Name", true));
            this.un_textBox1.Location = new System.Drawing.Point(216, 68);
            this.un_textBox1.Name = "un_textBox1";
            this.un_textBox1.Size = new System.Drawing.Size(164, 27);
            this.un_textBox1.TabIndex = 80;
            // 
            // id_label21
            // 
            this.id_label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.id_label21.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.appusers_bindingSource1, "id", true));
            this.id_label21.Location = new System.Drawing.Point(216, 26);
            this.id_label21.Name = "id_label21";
            this.id_label21.Size = new System.Drawing.Size(164, 28);
            this.id_label21.TabIndex = 79;
            this.id_label21.Text = "-";
            this.id_label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(84, 110);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 20);
            this.label9.TabIndex = 77;
            this.label9.Text = "Password:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(84, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 20);
            this.label5.TabIndex = 75;
            this.label5.Text = "User Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 33);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 20);
            this.label2.TabIndex = 74;
            this.label2.Text = "User ID:";
            // 
            // appUsersTableAdapter1
            // 
            this.appUsersTableAdapter1.ClearBeforeFill = true;
            // 
            // id_label5
            // 
            this.id_label5.AutoSize = true;
            this.id_label5.Location = new System.Drawing.Point(816, 125);
            this.id_label5.Name = "id_label5";
            this.id_label5.Size = new System.Drawing.Size(50, 20);
            this.id_label5.TabIndex = 7;
            this.id_label5.Text = "label5";
            // 
            // Users_de
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Linen;
            this.ClientSize = new System.Drawing.Size(785, 712);
            this.Controls.Add(this.id_label5);
            this.Controls.Add(this.main_gbox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.Top_Toolstrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Users_de";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Users Data Entry";
            this.Load += new System.EventHandler(this.Users_de_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Users_de_KeyDown);
            this.Top_Toolstrip.ResumeLayout(false);
            this.Top_Toolstrip.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.appusers_bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.letters1)).EndInit();
            this.main_gbox.ResumeLayout(false);
            this.main_gbox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.user_pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private ToolStrip Top_Toolstrip;
        private ToolStripButton add_butt;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripButton edit_butt;
        private ToolStripSeparator toolStripSeparator5;
        private ToolStripButton del_butt;
        private ToolStripSeparator toolStripSeparator4;
        private ToolStripButton save_butt;
        private ToolStripSeparator toolStripSeparator3;
        private ToolStripButton cancel_butt;
        private ToolStripSeparator toolStripSeparator6;
        private Panel panel1;
        private Label sys_time_lbl;
        private Label label8;
        private Label sys_date_lbl;
        private Label label6;
        private Label user_id_lbl;
        private Label label4;
        private Label user_name_lbl;
        private Label label1;
        private GroupBox main_gbox;
        private TextBox pass_textBox2;
        private TextBox un_textBox1;
        private Label id_label21;
        private Label label9;
        private Label label5;
        private Label label2;
        private TextBox pass_repeat_textBox1;
        private Label label3;
        private TextBox comment_textBox1;
        private Label label7;
        private Ds.Letters letters1;
        private BindingSource appusers_bindingSource1;
        private Ds.LettersTableAdapters.AppUsersTableAdapter appUsersTableAdapter1;
        public Label id_label5;
        private Button browse_button1;
        private PictureBox user_pictureBox1;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private CheckBox checkBox1;
        private CheckBox checkBox4;
        private CheckBox checkBox3;
        private CheckBox checkBox2;
        private CheckBox checkBox6;
        private CheckBox checkBox5;
        private CheckBox checkBox10;
        private CheckBox checkBox9;
        private CheckBox checkBox8;
        private CheckBox checkBox7;
        private CheckBox checkBox11;
        private GroupBox groupBox3;
        private CheckBox checkBox20;
        private CheckBox checkBox21;
        private CheckBox checkBox22;
        private GroupBox groupBox4;
        private CheckBox checkBox15;
        private CheckBox checkBox12;
        private CheckBox checkBox13;
        private CheckBox checkBox14;
        private GroupBox groupBox5;
        private CheckBox checkBox16;
        private CheckBox checkBox17;
        private CheckBox checkBox18;
        private CheckBox checkBox19;
        private GroupBox groupBox6;
        private CheckBox checkBox23;
        private CheckBox checkBox24;
        private CheckBox checkBox25;
        private GroupBox groupBox8;
        private CheckBox checkBox27;
        private CheckBox checkBox29;
        private CheckBox checkBox30;
        private GroupBox groupBox7;
        private CheckBox checkBox28;
    }
}